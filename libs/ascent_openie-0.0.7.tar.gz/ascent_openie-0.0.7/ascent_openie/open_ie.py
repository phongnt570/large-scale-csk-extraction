from typing import List, Dict, Any

import spacy
from spacy.tokens import Doc, Span

from ascent_openie.constants import SPACY_MODEL_NAME
from ascent_openie.stuffie import Stuffie


class AscentOIE(object):
    def __init__(self):
        self.nlp = spacy.load(SPACY_MODEL_NAME)

    def extract(self, text: str, simplify: bool = True, get_appos: bool = False) -> List[Dict[str, Any]]:
        return oie_from_spacy_doc(self.nlp(text), simplify=simplify, get_appos=get_appos)


def oie_from_spacy_doc(doc: Doc, simplify: bool = True, get_appos: bool = False) -> List[Dict[str, Any]]:
    assertion_list = []
    for sent in doc.sents:
        stuffie = Stuffie(sent, do_eval=False)
        stuffie.parse(get_appos=get_appos)
        assertion_list.extend(stuffie.assertions)
    return [a.to_dict(simplify=simplify, include_source=True) for a in assertion_list]


def oie_from_spacy_sent(sent: Span, simplify: bool = True, get_appos: bool = False) -> List[Dict[str, Any]]:
    stuffie = Stuffie(sent, do_eval=False)
    stuffie.parse(get_appos=get_appos)
    return [a.to_dict(simplify=simplify, include_source=True) for a in stuffie.assertions]
