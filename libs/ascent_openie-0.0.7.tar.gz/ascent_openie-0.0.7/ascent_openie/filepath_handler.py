import os
from pathlib import Path

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

RESOURCE_DIR = os.path.join(BASE_DIR, "resource")


# resource
def get_misc_dir():
    return Path(RESOURCE_DIR)


def get_pronouns_filepath():
    return get_misc_dir() / "pronouns.txt"


def get_ignored_pronouns_in_obj_filepath():
    return get_misc_dir() / "ignored_pronouns_in_object.txt"


def get_modal_verbs_filepath():
    return get_misc_dir() / "modal_verbs.txt"


def get_ignored_one_word_objects_filepath():
    return get_misc_dir() / "ignored_one_word_objects.txt"


def get_ignored_predicates_filepath():
    return get_misc_dir() / "ignored_predicates.txt"


def get_conjugate_exceptions_filepath():
    return get_misc_dir() / "conjugate_exceptions.txt"


def get_ignored_adverb_facets_filepath():
    return get_misc_dir() / "ignored_adverb_facets.txt"


def get_ignored_facet_prefixes_filepath():
    return get_misc_dir() / "ignored_facet_prefixes.txt"


def get_common_confusing_verbs_filepath():
    return get_misc_dir() / "common_confusing_verbs.txt"


def get_prepositions_filepath():
    return get_misc_dir() / "prepositions.txt"


def get_synonyms_tobe_filepath():
    return get_misc_dir() / "tobe_synonyms.txt"


def get_special_predicates_filepath():
    return get_misc_dir() / "special_predicates.txt"


def get_numeral_adjectives_filepath():
    return get_misc_dir() / "numeral_adjectives.txt"


def get_special_facet_connectors_filepath():
    return get_misc_dir() / "special_facet_connectors.txt"


def get_special_phrase_patterns_filepath():
    return get_misc_dir() / "special_phrase_patterns.json"


def get_redundant_predicate_prefixes_filepath():
    return get_misc_dir() / "redundant_predicate_prefixes.txt"


def get_redundant_predicate_suffixes_filepath():
    return get_misc_dir() / "redundant_predicate_suffixes.txt"


def get_facet_labels_filepath():
    return get_misc_dir() / "facet_labels.json"


def get_ignored_subgroups_filepath():
    return get_misc_dir() / "ignored_subgroups.txt"


def get_ignored_subparts_filepath():
    return get_misc_dir() / "ignored_subparts.txt"


def get_has_part_verbs_filepath():
    return get_misc_dir() / "has_part_verbs.txt"
