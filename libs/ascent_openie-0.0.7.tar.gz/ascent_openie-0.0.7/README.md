# Ascent OpenIE

The Open Information Extraction (OpenIE) module in the Ascent pipeline.