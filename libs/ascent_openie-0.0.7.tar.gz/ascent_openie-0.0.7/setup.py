from setuptools import setup, find_packages

VERSION = "0.0.7"
DESCRIPTION = "The Open Information Extraction (OpenIE) module in the Ascent pipeline"
LONG_DESCRIPTION = "The Open Information Extraction (OpenIE) module used in the Ascent pipeline, " \
                   "which is capable of extracting faceted open assertions."

REQUIRED_PACKAGES = [
    "spacy>=3.0.0,<3.1.0",
    "en_core_web_md @ https://github.com/explosion/spacy-models/releases/download/en_core_web_md-3.0.0/en_core_web_md-3.0.0.tar.gz",
]

setup(
    name="ascent_openie",
    version=VERSION,
    author="Tuan-Phong Nguyen",
    author_email="tuanphong@mpi-inf.mpg.de",
    url="https://ascent.mpi-inf.mpg.de",
    license="Apache 2.0",
    description=DESCRIPTION,
    long_description=LONG_DESCRIPTION,
    packages=find_packages(),
    package_data={"ascent_openie": ["resource/*.txt", "resource/*.json"]},
    install_requires=REQUIRED_PACKAGES,
    keywords=['ie', 'openie'],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Education",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ]
)
